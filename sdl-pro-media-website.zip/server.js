const express = require("express");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const http = require("http");
const https = require("https");
const cors = require("cors");
const bcrypt = require("bcryptjs");

// ----- Email (Nodemailer) -----
let mailer = null;
const SMTP_HOST = process.env.SMTP_HOST || "";
const SMTP_PORT = parseInt(process.env.SMTP_PORT || "587", 10);
const SMTP_USER = process.env.SMTP_USER || "";
const SMTP_PASS = process.env.SMTP_PASS || "";
const MAIL_FROM = process.env.MAIL_FROM || SMTP_USER || "noreply@sdlpromedia.com";
const OWNER_EMAIL = process.env.OWNER_EMAIL || "Levineshmuel98@gmail.com"; // where alerts are sent

if (SMTP_HOST && SMTP_USER && SMTP_PASS && OWNER_EMAIL) {
  try {
    const nodemailer = require("nodemailer");
    mailer = nodemailer.createTransport({
      host: SMTP_HOST,
      port: SMTP_PORT,
      secure: SMTP_PORT === 465,
      auth: { user: SMTP_USER, pass: SMTP_PASS },
    });
    console.log("  Email: configured → alerts go to " + OWNER_EMAIL);
  } catch (e) {
    console.log("  Email: nodemailer not installed. Run: npm install nodemailer");
  }
} else {
  console.log("  Email: Not configured. Set SMTP_HOST, SMTP_USER, SMTP_PASS, OWNER_EMAIL");
}

async function sendEmail(subject, text) {
  if (!mailer || !OWNER_EMAIL) {
    console.log("[Email skipped] " + subject + "\n" + text);
    return { ok: false, reason: "Email not configured. Set OWNER_EMAIL and SMTP settings." };
  }
  try {
    const info = await mailer.sendMail({
      from: '"SDL Pro Media" <' + MAIL_FROM + ">",
      to: OWNER_EMAIL,
      subject,
      text,
    });
    console.log("[Email sent] " + info.messageId);
    return { ok: true, id: info.messageId };
  } catch (err) {
    console.error("[Email error]", err.message);
    return { ok: false, reason: err.message };
  }
}

const app = express();
const PORT = process.env.PORT || 3000;
const USE_HTTPS = process.env.USE_HTTPS === "1" || process.env.USE_HTTPS === "true";
const ROOT = __dirname;
const PUBLIC = path.join(ROOT, "public");
const UPLOADS = path.join(ROOT, "uploads");
const DATA = path.join(ROOT, "data");
const CERTS = path.join(ROOT, "certs");

[UPLOADS, DATA, CERTS].forEach((dir) => {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
});

function readJSON(name, fallback) {
  const file = path.join(DATA, name);
  try {
    if (fs.existsSync(file)) return JSON.parse(fs.readFileSync(file, "utf8"));
  } catch (_) {}
  return fallback;
}
function writeJSON(name, data) {
  fs.writeFileSync(path.join(DATA, name), JSON.stringify(data, null, 2));
}

let media = readJSON("media.json", []);
let submissions = readJSON("submissions.json", []);
let pageViews = readJSON("page_views.json", []);
let settings = readJSON("settings.json", {});

if (!settings.admin_password) {
  settings.admin_password = bcrypt.hashSync("admin123", 10);
  writeJSON("settings.json", settings);
}
if (!settings.lastWeeklyEmail) {
  settings.lastWeeklyEmail = null;
  writeJSON("settings.json", settings);
}

const saveMedia = () => writeJSON("media.json", media);
const saveSubmissions = () => writeJSON("submissions.json", submissions);
const savePageViews = () => writeJSON("page_views.json", pageViews);
const saveSettings = () => writeJSON("settings.json", settings);

let nextMediaId = media.reduce((m, i) => Math.max(m, i.id || 0), 0) + 1;
let nextSubId = submissions.reduce((m, i) => Math.max(m, i.id || 0), 0) + 1;

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use("/uploads", express.static(UPLOADS));
app.use(express.static(PUBLIC));

app.use((req, res, next) => {
  if (process.env.FORCE_HTTPS === "1" && req.headers["x-forwarded-proto"] === "http") {
    return res.redirect(301, "https://" + req.headers.host + req.url);
  }
  next();
});

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOADS),
  filename: (_req, file, cb) => {
    const unique = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, unique + path.extname(file.originalname).toLowerCase());
  },
});
const fileFilter = (_req, file, cb) => {
  const ext = path.extname(file.originalname).toLowerCase().replace(".", "");
  const ok =
    /jpeg|jpg|png|gif|webp|mp4|webm|mov|avi/.test(ext) &&
    (file.mimetype.startsWith("image/") || file.mimetype.startsWith("video/"));
  cb(ok ? null : new Error("Only images and videos allowed"), ok);
};
const upload = multer({ storage, fileFilter, limits: { fileSize: 100 * 1024 * 1024 } });

function requireAdmin(req, res, next) {
  const token = req.headers["x-admin-token"] || req.query.token;
  if (settings.admin_token && token === settings.admin_token) return next();
  return res.status(401).json({ error: "Unauthorized. Please log in." });
}

// ========== PUBLIC ==========

app.post("/api/track", (req, res) => {
  pageViews.push({
    page: String(req.body.page || "home").slice(0, 100),
    viewed_at: new Date().toISOString(),
  });
  if (pageViews.length > 5000) pageViews = pageViews.slice(-5000);
  savePageViews();
  res.json({ ok: true });
});

app.get("/api/media", (_req, res) => {
  const list = media
    .slice()
    .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
    .map((m) => ({
      id: m.id,
      title: m.title,
      category: m.category,
      type: m.type,
      filename: m.filename,
      views: m.views || 0,
      created_at: m.created_at,
      url: "/uploads/" + m.filename,
    }));
  res.json({
    media: list,
    stats: {
      totalPageViews: pageViews.length,
      totalMediaViews: media.reduce((s, m) => s + (m.views || 0), 0),
    },
  });
});

app.post("/api/media/:id/view", (req, res) => {
  const item = media.find((m) => m.id === parseInt(req.params.id, 10));
  if (!item) return res.status(404).json({ error: "Not found" });
  item.views = (item.views || 0) + 1;
  saveMedia();
  res.json({ views: item.views });
});

// Contact / booking – save + email you right away
app.post("/api/contact", async (req, res) => {
  const { name, email, service, message } = req.body;
  if (!name || !email) {
    return res.status(400).json({ error: "Name and email are required" });
  }
  const entry = {
    id: nextSubId++,
    name: String(name).trim(),
    email: String(email).trim(),
    service: String(service || "").trim(),
    message: String(message || "").trim(),
    created_at: new Date().toISOString(),
  };
  submissions.unshift(entry);
  saveSubmissions();

  const subject = "SDL Pro Media – New booking from " + entry.name;
  const text =
    "New contact / booking received:\n\n" +
    "Name: " + entry.name + "\n" +
    "Email: " + entry.email + "\n" +
    "Service: " + (entry.service || "(none)") + "\n" +
    "Message:\n" + (entry.message || "(none)") + "\n\n" +
    "Time: " + entry.created_at + "\n";
  sendEmail(subject, text).catch(() => {});

  res.json({
    ok: true,
    message: "Thank you! Your message has been received.",
    id: entry.id,
  });
});

// ========== ADMIN ==========

app.post("/api/admin/login", (req, res) => {
  if (!bcrypt.compareSync(req.body.password || "", settings.admin_password)) {
    return res.status(401).json({ error: "Wrong password" });
  }
  settings.admin_token = bcrypt.hashSync(Date.now().toString() + Math.random(), 8);
  saveSettings();
  res.json({ token: settings.admin_token });
});

app.post("/api/admin/upload", requireAdmin, upload.single("file"), (req, res) => {
  if (!req.file) return res.status(400).json({ error: "No file uploaded" });
  const title = (req.body.title || req.file.originalname).trim();
  const category = (req.body.category || "portrait").toLowerCase();
  const type = req.file.mimetype.startsWith("video/") ? "video" : "image";
  const item = {
    id: nextMediaId++,
    title,
    category,
    type,
    filename: req.file.filename,
    original_name: req.file.originalname,
    views: 0,
    created_at: new Date().toISOString(),
  };
  media.push(item);
  saveMedia();
  res.json({
    ok: true,
    media: {
      id: item.id,
      title,
      category,
      type,
      filename: item.filename,
      url: "/uploads/" + item.filename,
      views: 0,
    },
  });
});

app.delete("/api/admin/media/:id", requireAdmin, (req, res) => {
  const idx = media.findIndex((m) => m.id === parseInt(req.params.id, 10));
  if (idx === -1) return res.status(404).json({ error: "Not found" });
  const fp = path.join(UPLOADS, media[idx].filename);
  if (fs.existsSync(fp)) fs.unlinkSync(fp);
  media.splice(idx, 1);
  saveMedia();
  res.json({ ok: true });
});

app.get("/api/admin/submissions", requireAdmin, (_req, res) => res.json({ submissions }));

app.get("/api/admin/stats", requireAdmin, (_req, res) => {
  res.json({
    totalPageViews: pageViews.length,
    totalMedia: media.length,
    totalMediaViews: media.reduce((s, m) => s + (m.views || 0), 0),
    totalSubmissions: submissions.length,
    recentViews: pageViews.slice(-20).reverse(),
    topMedia: media
      .slice()
      .sort((a, b) => (b.views || 0) - (a.views || 0))
      .slice(0, 10)
      .map((m) => ({
        id: m.id,
        title: m.title,
        category: m.category,
        type: m.type,
        views: m.views || 0,
      })),
    emailConfigured: !!(mailer && OWNER_EMAIL),
    ownerEmail: OWNER_EMAIL || null,
  });
});

app.post("/api/admin/change-password", requireAdmin, (req, res) => {
  const { newPassword } = req.body;
  if (!newPassword || newPassword.length < 6) {
    return res.status(400).json({ error: "Password must be at least 6 characters" });
  }
  settings.admin_password = bcrypt.hashSync(newPassword, 10);
  saveSettings();
  res.json({ ok: true });
});

app.post("/api/admin/test-email", requireAdmin, async (_req, res) => {
  const result = await sendEmail(
    "SDL Pro Media – test email",
    "This is a test. Email alerts are working.\n\nYou will get messages when someone books, plus a weekly viewer summary."
  );
  res.json(result);
});

app.get("*", (_req, res) => res.sendFile(path.join(PUBLIC, "index.html")));

app.use((err, _req, res, _next) => {
  if (err instanceof multer.MulterError || err.message) {
    return res.status(400).json({ error: err.message });
  }
  res.status(500).json({ error: "Server error" });
});

// ----- Weekly email summary -----
function sendWeeklySummary() {
  const now = new Date();
  const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
  const weekViews = pageViews.filter((v) => new Date(v.viewed_at) >= weekAgo).length;
  const weekBookings = submissions.filter((s) => new Date(s.created_at) >= weekAgo).length;
  const totalPageViews = pageViews.length;
  const totalMediaViews = media.reduce((s, m) => s + (m.views || 0), 0);

  const subject = "SDL Pro Media – Weekly report";
  const text =
    "Weekly summary for SDL Pro Media\n\n" +
    "Last 7 days – page views: " + weekViews + "\n" +
    "Last 7 days – bookings: " + weekBookings + "\n\n" +
    "All-time page views: " + totalPageViews + "\n" +
    "All-time media views: " + totalMediaViews + "\n" +
    "Media items in portfolio: " + media.length + "\n\n" +
    "— SDL Pro Media";

  sendEmail(subject, text).then((r) => {
    if (r.ok) {
      settings.lastWeeklyEmail = now.toISOString();
      saveSettings();
    }
  });
}

function scheduleWeeklyEmail() {
  setInterval(() => {
    const last = settings.lastWeeklyEmail ? new Date(settings.lastWeeklyEmail) : null;
    const now = new Date();
    const sevenDays = 7 * 24 * 60 * 60 * 1000;
    if (!last || now - last >= sevenDays) {
      const day = now.getDay();
      const hour = now.getHours();
      if (!last || (day === 1 && hour >= 9 && hour < 11) || now - last >= sevenDays + 24 * 60 * 60 * 1000) {
        console.log("Sending weekly email summary…");
        sendWeeklySummary();
      }
    }
  }, 60 * 60 * 1000);
}

function startServer() {
  scheduleWeeklyEmail();

  if (USE_HTTPS) {
    const keyPath = path.join(CERTS, "key.pem");
    const certPath = path.join(CERTS, "cert.pem");
    if (!fs.existsSync(keyPath) || !fs.existsSync(certPath)) {
      console.log("\n  HTTPS requested but no certificates in ./certs/");
      console.log("  Generating self-signed cert…");
      try {
        const { execSync } = require("child_process");
        execSync(
          'openssl req -x509 -newkey rsa:2048 -keyout "' +
            keyPath +
            '" -out "' +
            certPath +
            '" -days 365 -nodes -subj "/CN=localhost"',
          { stdio: "inherit" }
        );
      } catch (e) {
        console.error("  Could not generate cert. Falling back to HTTP.");
        http.createServer(app).listen(PORT, onListen);
        return;
      }
    }
    const options = {
      key: fs.readFileSync(keyPath),
      cert: fs.readFileSync(certPath),
    };
    https.createServer(options, app).listen(PORT, () => {
      console.log("\n  SDL Pro Media (HTTPS)");
      console.log("  Public site : https://localhost:" + PORT);
      console.log("  Admin panel : https://localhost:" + PORT + "/admin.html");
      console.log("  Default password: admin123");
      console.log("  Email alerts → " + (OWNER_EMAIL || "(not set)") + "\n");
    });
  } else {
    http.createServer(app).listen(PORT, onListen);
  }
}

function onListen() {
  console.log("\n  SDL Pro Media (HTTP)");
  console.log("  Public site : http://localhost:" + PORT);
  console.log("  Admin panel : http://localhost:" + PORT + "/admin.html");
  console.log("  Default password: admin123");
  console.log("  For HTTPS: USE_HTTPS=1 npm start");
  console.log("  Email alerts → " + (OWNER_EMAIL || "(not set)") + "\n");
}

startServer();
