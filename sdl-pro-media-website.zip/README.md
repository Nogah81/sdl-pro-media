# SDL Pro Media – Photography Website

Upload photos & videos, track views, capture bookings, and get **email** alerts.

## Features

- Professional portfolio website
- Admin panel to upload images & videos
- View counts on media + total site views
- Contact/booking form saves instantly
- **Instant email** when someone books
- **Weekly email** with viewer & booking summary
- HTTPS support

## Quick start

```bash
cd sdl-site
npm install
npm start
```

- Website: http://localhost:3000  
- Admin: http://localhost:3000/admin.html  
- Password: `admin123` (change in Settings)

## HTTPS

```bash
USE_HTTPS=1 npm start
```

Production: use Nginx/Caddy or a host with free HTTPS, and set `FORCE_HTTPS=1`.

## Email alerts

You’ll get:

| When | Email |
|------|--------|
| Someone submits the contact form | Immediate – name, email, service, message |
| Once a week (around Monday) | Page views & bookings (last 7 days) + all-time totals |

### Setup (Gmail example)

1. Turn on 2-Step Verification on your Google account  
2. Create an **App Password**: Google Account → Security → App passwords  
3. Set environment variables:

```bash
export OWNER_EMAIL="Levineshmuel98@gmail.com"
export SMTP_HOST="smtp.gmail.com"
export SMTP_PORT="587"
export SMTP_USER="Levineshmuel98@gmail.com"
export SMTP_PASS="your_16_char_app_password"
export MAIL_FROM="Levineshmuel98@gmail.com"

npm install
npm start
```

Or copy `.env.example` to `.env` and fill in the values (optional: `npm install dotenv` and add `require("dotenv").config()` at the top of `server.js`).

Other providers (Outlook, SendGrid, etc.) work the same – use their SMTP host/port and credentials.

### Test email

Admin → Settings → **Send Test Email**

## Environment variables

| Variable | Required | Description |
|----------|----------|-------------|
| `OWNER_EMAIL` | For alerts | Your email address |
| `SMTP_HOST` | For alerts | e.g. smtp.gmail.com |
| `SMTP_PORT` | For alerts | Usually 587 or 465 |
| `SMTP_USER` | For alerts | SMTP username |
| `SMTP_PASS` | For alerts | SMTP password / app password |
| `MAIL_FROM` | Optional | From address (defaults to SMTP_USER) |
| `USE_HTTPS` | Optional | `1` for HTTPS |
| `PORT` | Optional | Default 3000 |

## Folders

- `public/` – website + admin  
- `uploads/` – photos & videos  
- `data/` – submissions, views, settings  
- `certs/` – SSL for local HTTPS  
